No Screen Saver!
Version 2.0
Freeware


   No Screen Saver! is a little program that can disable screen 
saver during existing of defined windows on a desktop.

   It is particulary usefull in various repetitive situations - for 
example, if you writing a CD-ROM, it is recommended to switch 
off screen saver, so if you do that often, you must turn off and 
on screen saver every time. Or, when you have some slow 
and very CPU required processing that you do often and 
where screen saver will only slow down things more ...

   This little program will disable screen saver activation for you 
automatically !

   When it is started, it goes to tray automatically. Then, only 
thing you need to do is to define window's titles or part of titles 
and select checking type (case sensitive or not and full title 
check or check as a part of title - default is: no case 
sensitive/full title check) and when those windows exists on a 
desktop, screen saver will not be activated.

   After closing of defined windows, No Screen Saver! will 
enable screen saver again.

   You can enter window's titles manually or select them from a 
list of currently active windows. Note that leading and trailing 
spaces, if they exists, will not be removed from a title - neither 
in selection from active window list or in manual entering. So, 
checking will be precise unless you select "As part of title" 
when leading and trailing spaces will be ignored and text will 
be checked as a part of window's title.

   Titles that has "As part of title" unchecked will be 
represented with gray background in a list of windows so you 
can see their leading/trailing spaces if they exists. Also, you 
can choose "Case sensitive" to make checking more precise 
when caps and non-caps letters will be differed during check. 

   Time interval can be defined (from 1 to 10 seconds - default 
is 1) in which No Scren Saver! will check for existance of 
defined windows.

   No Screen Saver! also can start screen saver for you in any 
moment by simple clicking in appropriate popup menu option 
at tray icon.

   If you want, you can turn on option "Run with Windows" 
and No Screen Saver! will be started automatically every time 
you start Windows.


   Program is very easy to use - just follow options on screen ...


Disclaimer
=====================================================================
Program is freeware but copyrighted.

YOU MAY NOT SELL OR CHANGE THIS PROGRAM OR ANY OTHER PART OF THIS
PROGRAM OR DOCUMENTATION !

The author makes no warranties about it and accepts no responsibility
for any data loss or other system trouble that may occur from the
useage of No Screen Saver!.

Every effort has been made to ensure that no problems occur with
its usage.
=====================================================================

(c)1999-2001 m&g software, Pozega, Croatia
By Arminio Grgic

Arminio.Grgic@USA.Net
http://www.geocities.com/SiliconValley/Way/9629/arminio.htm
